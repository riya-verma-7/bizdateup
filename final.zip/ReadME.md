Starting Phase of BizDateUp
