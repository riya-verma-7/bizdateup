import React, { Component } from 'react';
import {Link} from 'react-router-dom';

const News = () => {
        return (
            <React.Fragment>
            <section className="section" id="contact">
              {/* <Container>
              
              </Container> */}
            </section>
          </React.Fragment>
        )
}
export default News;