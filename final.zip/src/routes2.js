// import React, { Component } from "react";
// // import routes from "../src/routes";
// import {
//   withRouter,
//   Route,
//   Switch,
//   BrowserRouter,
// } from "react-router-dom";

// import Layout1 from "../src/pages/Layout1/Layout1";
// import Layout2 from "../src/pages/Layout2/Layout2";
// import Layout3 from "../src/pages/Layout3/Layout3";
// import Layout4 from "../src/pages/Layout4/Layout4";
// import Layout5 from "../src/pages/Layout5/Layout5";
// import Layout6 from "../src/pages/Layout6/Layout6";
// import Login from "../src/component/Login";
// import SignUp from "../src/component/SignUp";
// import ForgotPassword from "../src/component/ForgotPassword";

// import "./assets/css/materialdesignicons.min.css";

// import "./assets/scss/themes.scss";

// const routes2 = ()=>{
//     // const [user, setUser] = useState({});

//     // const updateUser = (data) => {
//     //     setUser((prevUser) => ({ ...prevUser, ...data }));
//     // };

//     // const resetUser = () => {
//     //     setUser({});
//     // };
//     return(
//         <BrowserRouter>
//             <Switch>
                
//             </Switch>
//         </BrowserRouter>
//     );
// };

// export default routes2


// import React, { Component } from 'react';

// class Routes2 extends Component {
//   render() {
//     return (
//         <div>
//           <h2>About</h2>
//         </div>
//     );
//   }
// }

// export default Routes2;

import React from "react";
 const Routes2 = ()=>{
     return(
         <div>
             <h1>About</h1>
         </div>
     )
 }
 export default Routes2;